import logging
import pickle
import torch
import numpy as np
from ..dpwa import DpwaConnection


LOGGER = logging.getLogger(__name__)


TYPE_CONVERSION = {
    'torch.cuda.FloatTensor': np.float32,
    'torch.FloatTensor': np.float32
}


def _tensor_to_buffer(t):
    return bytes(t.cpu().numpy())


def _tensor_from_buffer_like(buf, t): # t:param.grad  [64, 3, 3, 3]

    n = np.frombuffer(buf, dtype=TYPE_CONVERSION[t.type()]) # buffer---->numpy ;tensor float32--->numpy float32;

    result = torch.from_numpy(n).view(t.size()) #numpy--->torch
    if t.is_cuda:
        result = result.cuda()
    return result


def _serialize_bytes_dict(params):
    return pickle.dumps(params)


def _deserialize_bytes_dict(blob):
    return pickle.loads(blob)


class DpwaPyTorchAdapter:
    def __init__(self, net, name, config_file):
        self._net = net
        self._conn = DpwaConnection(name, config_file)
        self.alpha=0.01
        #self.hp=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
        #self.hp=torch.zeros(54)
        self.hp =[]
        self.beta=1 # 衰减因子

    # 量化函数：
    def quantize(self,x,input_compress_settings={}):
        compress_settings = {'n': 6}
        compress_settings.update(input_compress_settings)
        # assume that x is a torch tensor
        n = compress_settings['n']
        # print('n:{}'.format(n))
        x = x.float()

        x_norm = torch.norm(x, p=float('inf'))

        sgn_x = ((x > 0).float() - 0.5) * 2

        p = torch.div(torch.abs(x), x_norm) # p 0~1 之间
        renormalize_p = torch.mul(p, n)
        floor_p = torch.floor(renormalize_p)
        compare = torch.rand_like(floor_p)  # rand_like()返回一个和输入大小相同的张量，其由均值为0、方差为1的标准正态分布填充

        final_p = renormalize_p - floor_p
        margin = (compare < final_p).float()
        xi = (floor_p + margin) / n

        Tilde_x = x_norm * sgn_x * xi
        return Tilde_x
        #Tilde_x_int8 = Tilde_x.type(torch.CharTensor)  # 返回int8
        #return Tilde_x_int8

    def quantize_Q(W, d=None, num_levels=2):
        """
        quantize input tensor W using QSGD method. the input tensor is reshaped into vecot form and divided into buckets of
        length d. it used maximum value of the vector as the scaling parameter for quantization. The output scale is such that
        by multiplying it with quantized values, the points will be reconstructed.
        :param W: input tensor to be quantizer
        :param d: bucket size
        :param num_levels: number of levels for quantizing |W|
        :return: quantized values and the scale
        """

        if d is None:
            d = W.size

        if W.size % d != 0:
            raise ValueError('the number of variables must be divisible by the bucket size (d).')

        w = np.reshape(W, newshape=(-1, d))
        norm_w = np.linalg.norm(w, ord=np.inf, axis=1) + np.finfo(float).eps
        
        # 1- normalize w
        sign_w = np.sign(w)
        y = np.abs(w) / norm_w[:, np.newaxis]

        # 2- initial quantization (q0(y) = l where y is in [l/s, (l+1)/s)
        q0 = np.floor(y * num_levels)  # an integer number in the range 0, 1, ..., s
        d = num_levels * y - q0  # d is the normalized distance of each point to the left boundary of the quantization interval

        # 3- create random binary numbers, b_i = 0 with probability (1-d) and b_i = 1 with probability d
        b = np.zeros(shape=w.shape)
        b[np.random.random(size=w.shape) < d] = 1

        q = sign_w * (q0 + b)
        scale = norm_w / num_levels

        Q = np.reshape(q, newshape=W.shape).astype(np.int)
        res=[Q, scale]
        return res

    def dequantize_Q(Q, scale, d=None):
        """
        dequantize the received quantized values, usign the bucket size d and scales
        :param Q: quantized values
        :param scale: scale to multiply to the quantized values to reconstruct the original data
        :param d: bucket size
        :return: ndarray of the same shape as Q, dequantized values
        """

        if d is None:
            d = Q.size

        if Q.size % d != 0:
            raise ValueError('the number of variables must be divisible by the bucket size (d).')

        if d == Q.size:
            W = scale[0] * Q
        else:
            q = np.reshape(Q, (-1, d))
            w = q * scale[:, np.newaxis]

            W = np.reshape(w, newshape=Q.shape)

        return W


    def update_send(self, batch_idx,loss,type="ECQ-SGD"):
        """Initiate an update to the cluster.

        Performs 2 things:
        1. Updates the local server with the latest parameters, so other peers could fetch them
        2. Initiate a fetch parameters request to a random peer.
        """
        if type=="ECQ-SGD":

            params = {}
            # 考虑迭代次数
            for layer_id,(name, param) in enumerate(self._net.named_parameters()): # 对每一层的梯度进行量化和补偿
                if batch_idx ==11:
                    s=param.grad.size()
                    self.hp.append(np.zeros(s))

                accum_hp=torch.from_numpy(self.hp[layer_id]) # 该层的累计量化误差  numpy ---> tensor
                grad_q =self.quantize(param.grad + self.alpha *accum_hp) # 该层的量化补偿
                hp_new = param.grad - grad_q + self.beta * accum_hp  # 累计量化误差
                self.hp[layer_id]= hp_new.numpy()  # tensor --->numpy
                param.grad = grad_q

                params[name] = _tensor_to_buffer(grad_q)
            blob = _serialize_bytes_dict(params)

            self._conn.update_send(blob, loss)
        else:
            "QSGD"
            params = {}
            # 考虑迭代次数
            for name, param in enumerate(self._net.named_parameters()): # 对每一层的梯度进行量化

                grad_np= torch.numpy(param.grad) # tensor-->numpy
                grad_q =self.quantize_Q(grad_np) 
                
                params[name] = _tensor_to_buffer(grad_q)
            blob = _serialize_bytes_dict(params)

            self._conn.update_send(blob, loss)

# 注意QSGD的量化和去量化的参数不一样，有无累积和补偿



    def update_wait(self,loss,type="ECQ-SGD"):
        """Waits for the cluster update to finish.

        Waiting for the fetch parameters request to complete (blocking)
        """
        if type=="ECQ-SGD":
            blob, factor = self._conn.update_wait(loss)
            if blob is None:
                return

            other_params = _deserialize_bytes_dict(blob)
            LOGGER.debug("Averaging. factor=%f", factor)
            for name, param in self._net.named_parameters():

                t = _tensor_from_buffer_like(other_params[name], param.grad)  # 这里param.grad 主要是传递该层的dtype
                #param.data = factor * t + (1 - factor) * param.data

                param.grad = factor * t + (1 - factor) * param.grad
                # 这里代码的感觉是对两个梯度参数平均，而不是 将接受到的P个节点一起平均
        else:
            "QSGD"
            
            blob, factor = self._conn.update_wait(loss)
            if blob is None:
                return

            other_params = _deserialize_bytes_dict(blob)

            LOGGER.debug("Averaging. factor=%f", factor)
            for name, param in self._net.named_parameters():
                # 去量化操作
                grad_recv,scale_recv = other_params[name]
                grad_de= self.dequantize_Q(grad_recv,scale_recv)

                t = _tensor_from_buffer_like(grad_de, param.grad)  
                #param.data = factor * t + (1 - factor) * param.data
                param.grad = factor * t + (1 - factor) * param.grad


    