

import pandas_alive
import pandas as pd
import matplotlib
matplotlib.rc("font",family='SimHei')



gongzi_t= pd.read_csv('datas/平均工资趋势.csv',index_col = 0,parse_dates =[0])

gongzi_t.plot_animated(filename='results/平均工资趋势.gif',n_visible=19,period_fmt="%Y",title='2016-2020平均工资趋势')