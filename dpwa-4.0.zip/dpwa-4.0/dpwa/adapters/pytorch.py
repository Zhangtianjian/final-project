import logging
import pickle
import torch
import numpy as np
import sys
from ..dpwa import DpwaConnection


LOGGER = logging.getLogger(__name__)


TYPE_CONVERSION = {
    'torch.cuda.FloatTensor': np.float32,
    'torch.FloatTensor': np.float32
}


def _tensor_to_buffer(t):
    # 改造
    #print(" numpy shape",t.cpu().numpy().shape)
    return bytes(t.cpu().numpy())


def _tensor_from_buffer_like(buf, t,q): # t:param.grad  [64, 3, 3, 3]

    if q=="qsgd": 

        norm_g,signs_g,l_g=buf
        signature_t=[]
        signature_t.append(np.frombuffer(norm_g, dtype=np.float32))
        signature_t.append(np.frombuffer(signs_g, dtype=np.bool))
        signature_t.append(np.frombuffer(l_g, dtype=np.int16))# 按照传输类型来定np.int8,np.int16,np.int32
        #signature_g = [np.frombuffer(j, dtype=TYPE_CONVERSION[t.type()]) for j in buf]
        """
        print("num:",len(signature_t))
        #print("signature_g",signature_t)
        print("0:",signature_t[0].shape)
        print("1:",signature_t[1].shape)
        print("2:",signature_t[2].shape)
        """
        result=[]
        if t.is_cuda:
           result.append(torch.from_numpy(signature_t[0]).cuda())
           result.append(torch.from_numpy(signature_t[1]).view(t.size()).cuda()) # signature_g中有该层的size
           result.append(torch.from_numpy(signature_t[2]).view(t.size()).cuda())
        else:
           result.append(torch.from_numpy(signature_t[0]))
           result.append(torch.from_numpy(signature_t[1]).view(t.size()))  # signature_g中有该层的size
           result.append(torch.from_numpy(signature_t[2]).view(t.size()))

        
    else:
        n = np.frombuffer(buf, dtype=TYPE_CONVERSION[t.type()]) # buffer---->numpy ; float32--->numpy float32;
        result = torch.from_numpy(n).view(t.size()) #numpy--->torch
    
        if t.is_cuda:
         result = result.cuda()
    return result


def _serialize_bytes_dict(params):
    return pickle.dumps(params)


def _deserialize_bytes_dict(blob):
    return pickle.loads(blob)


# args、size、shape 
class QSGDCompressor(object):
    def __init__(self, size, shape, args):
        self.random = args.random

        self.bit = args.n_bit   # 8bt,   int8
        c_dim = args.c_dim      # 指定的维度 32 
        assert self.bit > 0     

        self.cuda =  args.cuda
        self.s = 2 ** self.bit   # 2**8  长度256
        self.size = size      # 参数个数   param.flatten().shape[0]   #
        self.shape = shape    # 参数的维度 param.shpe     # 
        self.code_dtype = torch.int16 # 修改为int8 
        
    
        # 维度转换
        if c_dim == 0 or self.size < args.c_dim:
            self.dim = self.size  

        else:
            self.dim = c_dim  # size > c_dim 
            for i in range(0, 10):
                if size % self.dim != 0:
                    self.dim = self.dim // 2 * 3   # 不断的修改dim

        # 判断输出 
        """
        if c_dim != self.dim:
            print("alternate dimension form"
                  " {} to {}, size {} shape {}"
                  .format(c_dim, self.dim, size, shape))
        """
        assert self.dim != 0, \
            "0 sub dimension size {}  " \
            "c_dim {} self.dim {}"\
                .format(size, c_dim, self.dim)
        assert size % self.dim == 0, \
            "not divisible size {} " \
            " c_dim {} self.dim {}"\
                .format(size, c_dim, self.dim)

        # self.M = size // self.dim  
        
    

    def compress(self, vec):
        """
        :param vec: torch tensor
        :return: norm, signs, quantized_intervals
        """
        vec = vec.view(-1, self.dim)  # 改变维度

        # norm = torch.norm(vec, dim=1, keepdim=True)
        norm = torch.max(torch.abs(vec), dim=1, keepdim=True)[0] 
        normalized_vec = vec / norm # 标准化

        scaled_vec = torch.abs(normalized_vec) * self.s # 每一个值*256
        l = torch.clamp(scaled_vec, 0, self.s-1).type(self.code_dtype) # 根据上下限[0,255] 对 超过边界的值进行修改

        if self.random:
            # l[i] <- l[i] + 1 with probability |v_i| / ||v|| * s - l
            probabilities = scaled_vec - l.type(torch.float32) #    前后处理的差值： 差值都小于1 
            r = torch.rand(l.size()) # 产生n个[0,1)之间的随机值
            if self.cuda:
                r = r.cuda()
                probabilities=probabilities.cuda()
            l[:] += (probabilities > r).type(self.code_dtype)  # ????

        signs = torch.sign(vec) > 0
        """
        print("self.shape:",self.shape)
        print("signs",signs.shape)
        print("l",l.shape)
        """
        #print("norm",norm.dtype)
        #print("signs",signs.dtype)
        #print("l",l.dtype)
        return [norm, signs.view(self.shape), l.view(self.shape)]

    def decompress(self, signature):
        [norm, signs, l] = signature
        #print("----decompress-----")
        #print("l.shape:",l.shape)
        #print("signs.shape:",signs.shape)
        #print("self.dim",self.dim)
        assert l.shape == signs.shape
        scaled_vec = l.type(torch.float32) * (2 * signs.type(torch.float32) - 1)
        #compressed = (scaled_vec.view((-1,self.dim))) * norm / self.s
        compressed = (scaled_vec.view((self.dim,-1))) * norm / self.s # 修改后
        return compressed.view(self.shape)







class DpwaPyTorchAdapter:
    def __init__(self, net, name, config_file):
        self._net = net
        self._conn = DpwaConnection(name, config_file)
        self.alpha=0.01

        self.hp =[]
        self.beta=1 # 衰减因子
        self.compressor=list()
        

    # 量化函数：
    def quantize(self,x,input_compress_settings={}):
        compress_settings = {'n': 2147483648} # n=128,32768,2147483648
        compress_settings.update(input_compress_settings)
        # assume that x is a torch tensor
        n = compress_settings['n']
        # print('n:{}'.format(n))
        x = x.float()

        x_norm = torch.norm(x, p=float('inf'))
        sgn_x = ((x > 0).float() - 0.5) * 2

        p = torch.div(torch.abs(x), x_norm) # p 0~1 之间
        renormalize_p = torch.mul(p, n)
        floor_p = torch.floor(renormalize_p)
        compare = torch.rand_like(floor_p)  # rand_like()返回一个和输入大小相同的张量，其由均值为0、方差为1的标准正态分布填充

        final_p = renormalize_p - floor_p
        margin = (compare < final_p).float()
        xi = (floor_p + margin) / n
        """
        print("x_norm",x_norm)
        print("x",x)
        print("p",p.dtype,p)
        print("renormalize_p",renormalize_p.dtype,renormalize_p)
        print("floor_p",floor_p.dtype,floor_p)
        print("compare",compare.dtype,compare)
        print("final_p",final_p.dtype,final_p)
        print("margin",margin.dtype,margin)
        print("xi type",xi.dtype)
        print(xi)
        """

        Tilde_x = x_norm * sgn_x * xi
        return Tilde_x
        #Tilde_x_int8 = Tilde_x.type(torch.CharTensor)  # 返回int8
        #return Tilde_x_int8
        #Tilde_x_int16 = Tilde_x.type(torch.ShortTensor)  #torch.ShortTensor in16 
        #Tilde_x_int32 = Tilde_x.type(torch.FloatTensor)#torch.FloatTensor 、torch.IntTensor
        #return Tilde_x_int16



    def update_send(self, batch_idx,loss,args):
        """Initiate an update to the cluster.

        Performs 2 things:
        1. Updates the local server with the latest parameters, so other peers could fetch them
        2. Initiate a fetch parameters request to a random peer.
        """
        params = {}
        if args.quantizer=="ecqsgd":
            # 考虑迭代次数
            for layer_id,(name, param) in enumerate(self._net.named_parameters()): # 对每一层的梯度进行量化和补偿
                if batch_idx ==11:
                    s=param.grad.size()
                    self.hp.append(np.zeros(s))

                accum_hp=torch.from_numpy(self.hp[layer_id]) # 该层的累计量化误差  numpy ---> tensor

                grad_q =self.quantize(param.grad.cpu() + self.alpha *accum_hp) # 该层的量化补偿
                hp_new = param.grad.cpu() - grad_q + self.beta * accum_hp  # 累计量化误差
                self.hp[layer_id]= hp_new.numpy()  # tensor --->numpy
                param.grad = grad_q.cuda() if torch.cuda.is_available() else grad_q

                params[name] = _tensor_to_buffer(grad_q)
            blob = _serialize_bytes_dict(params)

            self._conn.update_send(blob, loss)
        elif args.quantizer=="qsgd":
            "QSGD"
            sum_c_size=0
            sum_t=0
            if  not self.compressor:
                for name, param in self._net.named_parameters(): # 对每一层的梯度进行量化
                    param_size = param.flatten().shape[0]
                    executor = QSGDCompressor(param_size, param.shape, args) 
                    self.compressor.append(executor)
                    grad_q= executor.compress(param.grad)

                    # 这里是否要把量化后的梯度赋值给param.grad
                    params[name] = [_tensor_to_buffer(g)  for g in grad_q] 
            else:

                for i,(name, param) in enumerate(self._net.named_parameters()): # 对每一层的梯度进行量化
                    grad_q= self.compressor[i].compress(param.grad)
                    
                    
                    # 这里是否要把量化后的梯度赋值给param.grad
                    params[name] = [_tensor_to_buffer(g)  for g in grad_q] 
                    c_size=sys.getsizeof(params[name])
                    c_test=sys.getsizeof(grad_q[0].storage())+ sys.getsizeof(grad_q[1].storage())+sys.getsizeof(grad_q[2].storage())
                    sum_t+=c_test
                    sum_c_size+=c_size

            blob = _serialize_bytes_dict(params)

            print("压缩后传输数据量：",sum_c_size)
            print("压缩校验:",sum_t)
            self._conn.update_send(blob, loss)

# 注意QSGD的量化和去量化的参数不一样，有无累积和补偿

    def update_wait(self,loss,args):
        """Waits for the cluster update to finish.

        Waiting for the fetch parameters request to complete (blocking)
        """
        if args.quantizer=="ecq-sgd":
            blob, factor = self._conn.update_wait(loss)
            if blob is None:
                return

            other_params = _deserialize_bytes_dict(blob)
            LOGGER.debug("Averaging. factor=%f", factor)
            for name, param in self._net.named_parameters():

                t = _tensor_from_buffer_like(other_params[name], param.grad,args.quantizer)  # 这里param.grad 主要是传递该层的dtype
                #param.data = factor * t + (1 - factor) * param.data

                param.grad = factor * t + (1 - factor) * param.grad
                # 这里代码的感觉是对两个梯度参数平均，而不是 将接受到的P个节点一起平均
        elif args.quantizer=="qsgd":
            "QSGD"
            
            blob, factor = self._conn.update_wait(loss)
            if blob is None:
                return

            other_params = _deserialize_bytes_dict(blob)

            LOGGER.debug("Averaging. factor=%f", factor)
            sum_de_size=0
            for i,(name, param) in enumerate(self._net.named_parameters()):
                # 去量化操作
                grad_recv= other_params[name]
                grad_tensor= _tensor_from_buffer_like(grad_recv, param.grad,args.quantizer)

                t= self.compressor[i].decompress(grad_tensor) # 解压缩
                de_size=sys.getsizeof(t.storage())
                sum_de_size+=de_size
                # t = _tensor_from_buffer_like(de_grad, param.grad)  
                #param.data = factor * t + (1 - factor) * param.data
                param.grad = factor * t + (1 - factor) * param.grad
            print("解压后的数据量:",sum_de_size)


    
