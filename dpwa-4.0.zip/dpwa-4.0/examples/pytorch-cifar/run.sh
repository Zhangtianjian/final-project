#!/bin/bash
OMP_NUM_THREADS=1 taskset -c 0 python3 main.py --lr=0.01 --batch-size 8 --name w0 --config-file ./dpwa.yaml & 
OMP_NUM_THREADS=1 taskset -c 1 python3 main.py --lr=0.01 --batch-size 8 --name w1 --config-file ./dpwa.yaml & 
wait

