#!/bin/bash

pkill python3

