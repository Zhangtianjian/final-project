import logging
import pickle
import torch
import numpy as np
from ..dpwa import DpwaConnection


LOGGER = logging.getLogger(__name__)


TYPE_CONVERSION = {
    'torch.cuda.FloatTensor': np.float32,
    'torch.FloatTensor': np.float32
}


def _tensor_to_buffer(t):
    return bytes(t.cpu().numpy())


def _tensor_from_buffer_like(buf, t): # t:param.grad  [64, 3, 3, 3]

    n = np.frombuffer(buf, dtype=TYPE_CONVERSION[t.type()]) # buffer---->numpy ;tensor float32--->numpy float32;

    result = torch.from_numpy(n).view(t.size()) #numpy--->torch
    if t.is_cuda:
        result = result.cuda()
    return result


def _serialize_bytes_dict(params):
    return pickle.dumps(params)


def _deserialize_bytes_dict(blob):
    return pickle.loads(blob)


class DpwaPyTorchAdapter:
    def __init__(self, net, name, config_file):
        self._net = net
        self._conn = DpwaConnection(name, config_file)
        self.alpha=0.01
        #self.hp=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
        #self.hp=torch.zeros(54)
        self.hp =[]
        self.beta=1 # 衰减因子

    # 量化函数：
    def quantize(self,x,input_compress_settings={}):
        compress_settings = {'n': 6}
        compress_settings.update(input_compress_settings)
        # assume that x is a torch tensor
        n = compress_settings['n']
        # print('n:{}'.format(n))
        x = x.float()

        x_norm = torch.norm(x, p=float('inf'))

        sgn_x = ((x > 0).float() - 0.5) * 2

        p = torch.div(torch.abs(x), x_norm) # p 0~1 之间
        renormalize_p = torch.mul(p, n)
        floor_p = torch.floor(renormalize_p)
        compare = torch.rand_like(floor_p)  # rand_like()返回一个和输入大小相同的张量，其由均值为0、方差为1的标准正态分布填充

        final_p = renormalize_p - floor_p
        margin = (compare < final_p).float()
        xi = (floor_p + margin) / n

        Tilde_x = x_norm * sgn_x * xi
        return Tilde_x
        #Tilde_x_int8 = Tilde_x.type(torch.CharTensor)  # 返回int8
        #return Tilde_x_int8




    def update_send(self, batch_idx,loss):
        """Initiate an update to the cluster.

        Performs 2 things:
        1. Updates the local server with the latest parameters, so other peers could fetch them
        2. Initiate a fetch parameters request to a random peer.
        """
        params = {}
        # 考虑迭代次数


        for layer_id,(name, param) in enumerate(self._net.named_parameters()): # 对每一层的梯度进行量化和补偿
            if batch_idx ==11:
                s=param.grad.size()
                self.hp.append(np.zeros(s))

            accum_hp=torch.from_numpy(self.hp[layer_id]) # 该层的累计量化误差  numpy ---> tensor
            grad_q =self.quantize(param.grad + self.alpha *accum_hp) # 该层的量化补偿
            q_error = param.grad - grad_q + self.beta * accum_hp  # 该层的量化误差
            self.hp[layer_id]+= q_error.numpy()  # tensor --->numpy
            #param.grad=grad_q # 把本地量化后的梯度grad_q  赋值给parameter.grad

            param.grad = grad_q
            params[name] = _tensor_to_buffer(grad_q)

        blob = _serialize_bytes_dict(params)

        self._conn.update_send(blob, loss)


    def update_wait(self,loss):
        """Waits for the cluster update to finish.

        Waiting for the fetch parameters request to complete (blocking)
        """
        blob, factor = self._conn.update_wait(loss)
        if blob is None:
            return

        other_params = _deserialize_bytes_dict(blob)
        LOGGER.debug("Averaging. factor=%f", factor)
        for name, param in self._net.named_parameters():

            t = _tensor_from_buffer_like(other_params[name], param.grad)  # 这里param.grad 主要是传递该层的dtype
            #param.data = factor * t + (1 - factor) * param.data

            param.grad = factor * t + (1 - factor) * param.grad

    # 这里代码的感觉是对两个梯度参数平均，而不是 将接受到的P个节点一起平均